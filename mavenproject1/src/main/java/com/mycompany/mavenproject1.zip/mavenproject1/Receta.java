package com.mycompany.mavenproject1;

public class Receta {
    private int idReceta;
    private int idProducto;
    private int idIngrediente;
    private double cantidadNecesaria;

    // Campos extra útiles para el Front (opcionales pero te salvarán la vida)
    private String nombreIngrediente; 
    private String unidadMedida;      

    public Receta() {}

    // Constructor básico para insertar
    public Receta(int idProducto, int idIngrediente, double cantidadNecesaria) {
        this.idProducto = idProducto;
        this.idIngrediente = idIngrediente;
        this.cantidadNecesaria = cantidadNecesaria;
    }

    // Constructor completo para leer datos de la BD con nombres incluidos
    public Receta(int idReceta, int idProducto, int idIngrediente, double cantidadNecesaria, String nombreIngrediente, String unidadMedida) {
        this.idReceta = idReceta;
        this.idProducto = idProducto;
        this.idIngrediente = idIngrediente;
        this.cantidadNecesaria = cantidadNecesaria;
        this.nombreIngrediente = nombreIngrediente;
        this.unidadMedida = unidadMedida;
    }

    // Getters y Setters
    public int getIdReceta() { return idReceta; }
    public void setIdReceta(int idReceta) { this.idReceta = idReceta; }
    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }
    public int getIdIngrediente() { return idIngrediente; }
    public void setIdIngrediente(int idIngrediente) { this.idIngrediente = idIngrediente; }
    public double getCantidadNecesaria() { return cantidadNecesaria; }
    public void setCantidadNecesaria(double cantidadNecesaria) { this.cantidadNecesaria = cantidadNecesaria; }
    public String getNombreIngrediente() { return nombreIngrediente; }
    public void setNombreIngrediente(String nombreIngrediente) { this.nombreIngrediente = nombreIngrediente; }
    public String getUnidadMedida() { return unidadMedida; }
    public void setUnidadMedida(String unidadMedida) { this.unidadMedida = unidadMedida; }
}