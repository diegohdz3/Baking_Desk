package com.mycompany.mavenproject1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    // ==========================================
    // SECCIÓN CATEGORÍAS
    // ==========================================
    public List<CategoriaProducto> listarCategorias() {
        List<CategoriaProducto> lista = new ArrayList<>();
        String sql = "SELECT * FROM Categoria_Producto";
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new CategoriaProducto(
                    rs.getInt("id_categoria"),
                    rs.getString("nombre"),
                    rs.getString("descripcion")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // ==========================================
    // SECCIÓN PRODUCTOS
    // ==========================================

    // 1. REGISTRAR PRODUCTO (Devuelve el ID generado para asociarle su receta sin error 500)
    public int registrar(Producto prod) {
        String sql = "INSERT INTO Producto (nombre, descripcion, precio, stock_actual, categoria_id, estado) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            ps.setString(1, prod.getNombre());
            ps.setString(2, prod.getDescripcion());
            ps.setDouble(3, prod.getPrecio());
            ps.setInt(4, prod.getStockActual());
            ps.setString(5, prod.getIdCategoria());
            ps.setString(6, prod.getEstado());

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getInt(1); // Retorna el ID asignado por MySQL
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Falló la inserción
    }

    // 2. LISTAR TODOS LOS PRODUCTOS
    public List<Producto> listarTodos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM Producto";
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Producto(
                    rs.getInt("id"), 
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio"),
                    rs.getInt("stock_actual"),
                    rs.getString("categoria_id"),
                    rs.getString("estado")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // 3. BUSCAR PRODUCTO POR ID
    public Producto buscarPorId(int id) {
        String sql = "SELECT * FROM Producto WHERE id = ?";
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Producto(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getDouble("precio"),
                        rs.getInt("stock_actual"),
                        rs.getString("categoria_id"),
                        rs.getString("estado")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // 4. ACTUALIZAR PRODUCTO + RESTAR INGREDIENTES AUTOMÁTICAMENTE SI AUMENTA EL STOCK
    public boolean actualizar(Producto prod) {
        String sqlSelectStock = "SELECT stock_actual FROM Producto WHERE id = ?";
        String sqlUpdateProducto = "UPDATE Producto SET nombre = ?, descripcion = ?, precio = ?, stock_actual = ?, categoria_id = ?, estado = ? WHERE id = ?";
        String sqlReceta = "SELECT id_ingrediente, cantidad_necesaria FROM Receta WHERE id_producto = ?";
        String sqlRestarIngrediente = "UPDATE Ingrediente SET stock_actual = stock_actual - ? WHERE id = ?";
        String sqlMovimiento = "INSERT INTO Movimiento_Inventario (ingrediente_id, tipo, cantidad, motivo) VALUES (?, 'salida', ?, 'produccion_producto')";

        Connection con = null;
        try {
            con = ConexionBD.getConexion();
            con.setAutoCommit(false); // Transacción atómica

            // A) Obtener el stock anterior del producto para saber cuántas unidades nuevas se agregaron
            int stockAnterior = 0;
            try (PreparedStatement psSel = con.prepareStatement(sqlSelectStock)) {
                psSel.setInt(1, prod.getIdProducto());
                ResultSet rs = psSel.executeQuery();
                if (rs.next()) {
                    stockAnterior = rs.getInt("stock_actual");
                }
            }

            int unidadesProducidas = prod.getStockActual() - stockAnterior;

            // B) Actualizar los datos del producto
            try (PreparedStatement psUpd = con.prepareStatement(sqlUpdateProducto)) {
                psUpd.setString(1, prod.getNombre());
                psUpd.setString(2, prod.getDescripcion());
                psUpd.setDouble(3, prod.getPrecio());
                psUpd.setInt(4, prod.getStockActual());
                psUpd.setString(5, prod.getIdCategoria());
                psUpd.setString(6, prod.getEstado());
                psUpd.setInt(7, prod.getIdProducto());
                psUpd.executeUpdate();
            }

            // C) Si se incrementó el stock del producto (> 0), descontar ingredientes de la Receta
            if (unidadesProducidas > 0) {
                try (PreparedStatement psReceta = con.prepareStatement(sqlReceta);
                     PreparedStatement psRestar = con.prepareStatement(sqlRestarIngrediente);
                     PreparedStatement psMov = con.prepareStatement(sqlMovimiento)) {

                    psReceta.setInt(1, prod.getIdProducto());
                    ResultSet rsReceta = psReceta.executeQuery();

                    while (rsReceta.next()) {
                        int idIngrediente = rsReceta.getInt("id_ingrediente");
                        double cantidadNecesaria = rsReceta.getDouble("cantidad_necesaria");
                        
                        // Total a descontar = (Cantidad requerida por receta) * (Nuevas unidades producidas)
                        double totalARestar = cantidadNecesaria * unidadesProducidas;

                        // Prepara resta en Ingrediente
                        psRestar.setDouble(1, totalARestar);
                        psRestar.setInt(2, idIngrediente);
                        psRestar.addBatch();

                        // Prepara auditoría de salida
                        psMov.setInt(1, idIngrediente);
                        psMov.setDouble(2, totalARestar);
                        psMov.addBatch();
                    }

                    psRestar.executeBatch();
                    psMov.executeBatch();
                }
            }

            con.commit(); // Confirmar cambios
            return true;

        } catch (SQLException e) {
            if (con != null) {
                try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            e.printStackTrace();
            return false;
        } finally {
            if (con != null) {
                try { con.setAutoCommit(true); con.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }

    // 5. ELIMINAR PRODUCTO
    public boolean eliminar(int id) {
        String sql = "DELETE FROM Producto WHERE id = ?";
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;  
        }
    }

    // ==========================================
    // MÉTODO TRANSACCIONAL DE VENTAS (PEDIDO -> INGRESO)
    // ==========================================
    public boolean actualizarEstadoYGenerarIngreso(int pedidoId, String nuevoEstado, double totalPedido) {
        String updatePedidoSql = "UPDATE Pedido SET estado = ? WHERE id = ?";
        String insertIngresoSql = "INSERT INTO Ingreso (pedido_id, concepto, monto, fecha) VALUES (?, ?, ?, CURDATE())";

        Connection con = null;
        PreparedStatement psUpdate = null;
        PreparedStatement psInsert = null;
        boolean exito = false;

        try {
            con = ConexionBD.getConexion();
            con.setAutoCommit(false);

            psUpdate = con.prepareStatement(updatePedidoSql);
            psUpdate.setString(1, nuevoEstado);
            psUpdate.setInt(2, pedidoId);
            int filasActualizadas = psUpdate.executeUpdate();

            if (filasActualizadas > 0) {
                if ("entregado".equalsIgnoreCase(nuevoEstado)) {
                    String concepto = "Pago automático de pedido #" + pedidoId;
                    
                    psInsert = con.prepareStatement(insertIngresoSql);
                    psInsert.setInt(1, pedidoId);
                    psInsert.setString(2, concepto);
                    psInsert.setDouble(3, totalPedido);
                    psInsert.executeUpdate();
                }
                
                con.commit();
                exito = true;
            } else {
                con.rollback();
            }

        } catch (SQLException e) {
            e.printStackTrace();
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            try {
                if (psUpdate != null) psUpdate.close();
                if (psInsert != null) psInsert.close();
                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return exito;
    }
}