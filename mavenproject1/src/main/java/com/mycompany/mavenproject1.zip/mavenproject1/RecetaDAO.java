package com.mycompany.mavenproject1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RecetaDAO {

    // 1. Obtener la receta de un producto
    public List<Receta> obtenerPorProducto(int idProducto) {
        List<Receta> lista = new ArrayList<>();
        // Corrección en el JOIN: i.id en lugar de i.id_ingrediente
        String sql = "SELECT r.*, i.nombre AS nombre_ingrediente, i.unidad_medida " +
                     "FROM Receta r " +
                     "JOIN Ingrediente i ON r.id_ingrediente = i.id " +
                     "WHERE r.id_producto = ?";
        
        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setInt(1, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Receta(
                        rs.getInt("id_receta"),
                        rs.getInt("id_producto"),
                        rs.getInt("id_ingrediente"),
                        rs.getDouble("cantidad_necesaria"),
                        rs.getString("nombre_ingrediente"),
                        rs.getString("unidad_medida")
                    ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

public boolean guardarReceta(int idProducto, List<Receta> detallesReceta) {
    // ⚠️ Tablas en minúsculas para compatibilidad con Linux/AWS
    String sqlDelete = "DELETE FROM receta WHERE id_producto = ?"; 
    String sqlInsert = "INSERT INTO receta (id_producto, id_ingrediente, cantidad_necesaria) VALUES (?, ?, ?)";
    Connection con = null;

    try {
        con = ConexionBD.getConexion();
        con.setAutoCommit(false); 

        // 1. Borrar receta anterior
        try (PreparedStatement psDel = con.prepareStatement(sqlDelete)) {
            psDel.setInt(1, idProducto);
            psDel.executeUpdate();
        }

        // 2. Insertar nuevos ingredientes
        if (detallesReceta != null && !detallesReceta.isEmpty()) {
            try (PreparedStatement psIns = con.prepareStatement(sqlInsert)) {
                for (Receta item : detallesReceta) {
                    psIns.setInt(1, idProducto);
                    psIns.setInt(2, item.getIdIngrediente());
                    psIns.setDouble(3, item.getCantidadNecesaria());
                    psIns.addBatch();
                }
                psIns.executeBatch();
            }
        }

        con.commit();
        return true;

    } catch (SQLException e) {
        if (con != null) {
            try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
        }
        System.err.println("❌ ERROR MYSQL EN RECETA DAO:");
        e.printStackTrace(); // Revisa la consola donde corre Maven/Java
        return false;
    } finally {
        if (con != null) {
            try { con.setAutoCommit(true); con.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}
}