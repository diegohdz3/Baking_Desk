package com.mycompany.mavenproject1;

import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class DashboardDAO {

    public DashboardResumen obtenerResumen() {
        DashboardResumen resumen = new DashboardResumen();
        
        DashboardResumen.Stats stats = new DashboardResumen.Stats();
        stats.pedidosHoy = 0;
        stats.ventasHoy = BigDecimal.ZERO;
        stats.productosBajos = 0;
        stats.clientes = 0;
        
        DashboardResumen.PedidosEstado estados = new DashboardResumen.PedidosEstado();
        estados.nuevo = 0;
        estados.enCurso = 0;
        estados.listo = 0;
        estados.entregado = 0;
        estados.total = 0;

        List<BigDecimal> ventasSemana = new ArrayList<>();
        // Inicializamos los 7 días de la semana (Lunes a Domingo) en cero
        for (int i = 0; i < 7; i++) {
            ventasSemana.add(BigDecimal.ZERO);
        }

        List<DashboardResumen.PedidoReciente> recientes = new ArrayList<>();

        try (Connection con = ConexionBD.getConexion()) {
            
            // ==========================================
            // 1. CARGAR TARJETAS MÉTRICAS (STATS)
            // ==========================================
            
            // Pedidos creados el día de hoy
            String sqlPedidosHoy = "SELECT COUNT(*) FROM Pedido WHERE DATE(created_at) = CURDATE()";
            try (PreparedStatement ps = con.prepareStatement(sqlPedidosHoy);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.pedidosHoy = rs.getInt(1);
            }

            // Ventas concretadas hoy (Suma de montos en Ingresos del día de hoy)
            String sqlVentasHoy = "SELECT COALESCE(SUM(monto), 0) FROM Ingreso WHERE fecha = CURDATE()";
            try (PreparedStatement ps = con.prepareStatement(sqlVentasHoy);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.ventasHoy = rs.getBigDecimal(1);
            }

            // Insumos por debajo o igual al stock mínimo
            String sqlBajos = "SELECT COUNT(*) FROM Ingrediente WHERE stock_actual <= stock_minimo";
            try (PreparedStatement ps = con.prepareStatement(sqlBajos);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.productosBajos = rs.getInt(1);
            }

            // Clientes activos registrados
            String sqlClientes = "SELECT COUNT(*) FROM Cliente WHERE estado = 'activo'";
            try (PreparedStatement ps = con.prepareStatement(sqlClientes);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.clientes = rs.getInt(1);
            }
            resumen.setStats(stats);

            // ==========================================
            // 2. VENTAS DE LA SEMANA (LUNES A DOMINGO)
            // ==========================================
            // WEEKDAY() en MariaDB devuelve 0 para Lunes, 1 para Martes... 6 para Domingo.
            String sqlVentaSemanal = "SELECT WEEKDAY(fecha) as dia_semana, SUM(monto) as total " +
                                     "FROM Ingreso " +
                                     "WHERE YEARWEEK(fecha, 1) = YEARWEEK(CURDATE(), 1) " +
                                     "GROUP BY WEEKDAY(fecha)";
            try (PreparedStatement ps = con.prepareStatement(sqlVentaSemanal);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int index = rs.getInt("dia_semana");
                    if (index >= 0 && index < 7) {
                        ventasSemana.set(index, rs.getBigDecimal("total"));
                    }
                }
            }
            resumen.setVentasSemana(ventasSemana);

            // ==========================================
            // 3. GRÁFICO DONA: PEDIDOS POR ESTADO
            // ==========================================
            String sqlEstados = "SELECT estado, COUNT(*) as cantidad FROM Pedido GROUP BY estado";
            try (PreparedStatement ps = con.prepareStatement(sqlEstados);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String est = rs.getString("estado").toLowerCase();
                    int cant = rs.getInt("cantidad");
                    
                    switch (est) {
                        case "nuevo":
                            estados.nuevo = cant;
                            break;
                        case "en curso":
                            estados.enCurso = cant;
                            break;
                        case "listo":
                            estados.listo = cant;
                            break;
                        case "entregado":
                            estados.entregado = cant;
                            break;
                    }
                }
                // El total a graficar en la dona es la suma de los estados activos (excluyendo cancelados)
                estados.total = estados.nuevo + estados.enCurso + estados.listo + estados.entregado;
            }
            resumen.setPedidosEstado(estados);

            // ==========================================
            // 4. TABLA: PEDIDOS RECIENTES (Últimos 5)
            // ==========================================
            String sqlRecientes = 
                "SELECT p.id, c.nombre AS cliente, p.fecha_entrega, p.estado, p.total, " +
                "       COALESCE((SELECT GROUP_CONCAT(prod.nombre SEPARATOR ', ') " +
                "                 FROM Detalle_Pedido dp " +
                "                 JOIN Producto prod ON dp.producto_id = prod.id " +
                "                 WHERE dp.pedido_id = p.id), 'Sin productos') AS productos " +
                "FROM Pedido p " +
                "JOIN Cliente c ON p.cliente_id = c.id " +
                "ORDER BY p.created_at DESC LIMIT 5";

            try (PreparedStatement ps = con.prepareStatement(sqlRecientes);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    DashboardResumen.PedidoReciente pr = new DashboardResumen.PedidoReciente();
                    pr.id = rs.getInt("id");
                    pr.cliente = rs.getString("cliente");
                    pr.producto = rs.getString("productos");
                    pr.fechaEntrega = rs.getDate("fecha_entrega").toString();
                    pr.estado = rs.getString("estado");
                    pr.total = rs.getBigDecimal("total");
                    recientes.add(pr);
                }
            }
            resumen.setPedidosRecientes(recientes);

        } catch (SQLException e) {
            System.err.println("Error al compilar métricas del Dashboard: " + e.getMessage());
        }

        return resumen;
    }
}