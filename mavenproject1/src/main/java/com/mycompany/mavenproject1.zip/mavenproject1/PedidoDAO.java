package com.mycompany.mavenproject1;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    // 1. CREAR UN NUEVO PEDIDO CON SU DETALLE (Transaccional)
    public boolean crearPedido(Pedido pedido) {
        String sqlPedido = "INSERT INTO Pedido (cliente_id, usuario_id, estado, total, notas, fecha_entrega) VALUES (?, ?, ?, ?, ?, ?)";
        String sqlDetalle = "INSERT INTO Detalle_Pedido (pedido_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        String sqlIngreso = "INSERT INTO Ingreso (concepto, monto, fecha, pedido_id) " +
                            "SELECT CONCAT('Pedido #', p.id, ' - ', COALESCE(c.nombre, 'Cliente Directo')), " +
                            "       p.total, CURRENT_DATE(), p.id " +
                            "FROM Pedido p " +
                            "LEFT JOIN Cliente c ON p.cliente_id = c.id " +
                            "WHERE p.id = ? " +
                            "AND NOT EXISTS (SELECT 1 FROM Ingreso WHERE pedido_id = ?)";

        Connection con = null;
        PreparedStatement psPedido = null;
        PreparedStatement psDetalle = null;
        ResultSet rsKeys = null;

        try {
            con = ConexionBD.getConexion();
            con.setAutoCommit(false); // Activamos control de transacciones de forma estricta

            // PASO A: Insertar en la tabla Pedido (Cabecera)
            psPedido = con.prepareStatement(sqlPedido, Statement.RETURN_GENERATED_KEYS);
            psPedido.setInt(1, pedido.getClienteId());
            psPedido.setInt(2, pedido.getUsuarioId() > 0 ? pedido.getUsuarioId() : 1);
            
            String estadoFormateado = (pedido.getEstado() == null || pedido.getEstado().trim().isEmpty()) 
                    ? "nuevo" 
                    : pedido.getEstado().replace("\"", "").trim();
            psPedido.setString(3, estadoFormateado);
            
            psPedido.setDouble(4, pedido.getTotal());
            psPedido.setString(5, pedido.getNotas());
            psPedido.setString(6, pedido.getFechaEntrega());
            
            psPedido.executeUpdate();

            // PASO B: Obtener el ID autogenerado del pedido
            rsKeys = psPedido.getGeneratedKeys();
            int idPedidoGenerado = 0;
            if (rsKeys.next()) {
                idPedidoGenerado = rsKeys.getInt(1);
            } else {
                throw new SQLException("No se pudo obtener el ID generado para el Pedido.");
            }

            // PASO C: Insertar los productos en Detalle_Pedido
            if (pedido.getDetalles() != null && !pedido.getDetalles().isEmpty()) {
                psDetalle = con.prepareStatement(sqlDetalle);
                for (DetallePedido detalle : pedido.getDetalles()) {
                    psDetalle.setInt(1, idPedidoGenerado);
                    psDetalle.setInt(2, detalle.getProductoId());
                    psDetalle.setInt(3, detalle.getCantidad());
                    psDetalle.setDouble(4, detalle.getPrecioUnitario());
                    psDetalle.addBatch();
                }
                psDetalle.executeBatch();
            }

            // PASO D: Si el pedido se crea directamente como 'entregado', generar el ingreso financiero
            if ("entregado".equalsIgnoreCase(estadoFormateado)) {
                try (PreparedStatement psIngreso = con.prepareStatement(sqlIngreso)) {
                    psIngreso.setInt(1, idPedidoGenerado);
                    psIngreso.setInt(2, idPedidoGenerado);
                    psIngreso.executeUpdate();
                }
            }

            con.commit(); // Confirmamos todos los cambios si no hubo fallos
            return true;

        } catch (SQLException e) {
            System.err.println("ERROR SQL al registrar pedido: " + e.getMessage());
            e.printStackTrace();
            if (con != null) {
                try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            return false;
        } finally {
            try { if (rsKeys != null) rsKeys.close(); } catch (SQLException e) {}
            try { if (psPedido != null) psPedido.close(); } catch (SQLException e) {}
            try { if (psDetalle != null) psDetalle.close(); } catch (SQLException e) {}
            try { if (con != null) { con.setAutoCommit(true); con.close(); } } catch (SQLException e) {}
        }
    }

    // 2. OBTENER TODOS LOS PEDIDOS CON DATOS DEL CLIENTE Y PRODUCTO PRINCIPAL
    public List<Pedido> obtenerTodos() {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT p.*, c.nombre AS nombre_cliente, MAX(prod.nombre) AS nombre_producto " +
                     "FROM Pedido p " +
                     "JOIN Cliente c ON p.cliente_id = c.id " +
                     "LEFT JOIN Detalle_Pedido dp ON p.id = dp.pedido_id " +
                     "LEFT JOIN Producto prod ON dp.producto_id = prod.id " +
                     "GROUP BY p.id " +
                     "ORDER BY p.id DESC";

        try (Connection con = ConexionBD.getConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Pedido p = new Pedido();
                p.setId(rs.getInt("id"));
                p.setClienteId(rs.getInt("cliente_id"));
                p.setUsuarioId(rs.getInt("usuario_id"));
                p.setEstado(rs.getString("estado"));
                p.setTotal(rs.getDouble("total"));
                p.setNotas(rs.getString("notas")); 
                p.setFechaEntrega(rs.getString("fecha_entrega"));
                p.setCreatedAt(rs.getString("created_at"));
                p.setNombreCliente(rs.getString("nombre_cliente"));
                p.setNombreProducto(rs.getString("nombre_producto")); 
                
                lista.add(p);
            }
        } catch (SQLException e) {
            System.err.println("ERROR SQL al listar pedidos: " + e.getMessage());
            e.printStackTrace();
        }
        return lista;
    }

    // 3. OBTENER EL DETALLE COMPLETO DE UN PEDIDO ESPECÍFICO
    public List<DetallePedido> obtenerDetallePorPedido(int idPedido) {
        List<DetallePedido> lista = new ArrayList<>();
        String sql = "SELECT dp.*, pr.nombre AS nombre_producto " +
                     "FROM Detalle_Pedido dp " +
                     "JOIN Producto pr ON dp.producto_id = pr.id " +
                     "WHERE dp.pedido_id = ?";

        try (Connection con = ConexionBD.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    DetallePedido dp = new DetallePedido();
                    dp.setId(rs.getInt("id"));
                    dp.setPedidoId(rs.getInt("pedido_id"));
                    dp.setProductoId(rs.getInt("producto_id"));
                    dp.setCantidad(rs.getInt("cantidad"));
                    dp.setPrecioUnitario(rs.getDouble("precio_unitario"));
                    dp.setSubtotal(rs.getDouble("subtotal"));
                    dp.setNombreProducto(rs.getString("nombre_producto"));
                    lista.add(dp);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // 4. ACTUALIZAR EL ESTADO DE UN PEDIDO (Y generar Ingreso automático si es 'entregado')
    public boolean actualizarEstado(int idPedido, String nuevoEstado) {
        String estadoLimpio = (nuevoEstado != null) ? nuevoEstado.replace("\"", "").trim() : "";

        String sqlUpdate = "UPDATE Pedido SET estado = ? WHERE id = ?";
        String sqlIngreso = "INSERT INTO Ingreso (concepto, monto, fecha, pedido_id) " +
                            "SELECT CONCAT('Pedido #', p.id, ' - ', COALESCE(c.nombre, 'Cliente Directo')), " +
                            "       p.total, CURRENT_DATE(), p.id " +
                            "FROM Pedido p " +
                            "LEFT JOIN Cliente c ON p.cliente_id = c.id " +
                            "WHERE p.id = ? " +
                            "AND NOT EXISTS (SELECT 1 FROM Ingreso WHERE pedido_id = ?)";

        Connection con = null;
        try {
            con = ConexionBD.getConexion();
            con.setAutoCommit(false); // Iniciamos transacción para asegurar ambas tablas

            // Paso A: Actualizar el estado del pedido
            try (PreparedStatement psUpdate = con.prepareStatement(sqlUpdate)) {
                psUpdate.setString(1, estadoLimpio);
                psUpdate.setInt(2, idPedido);
                psUpdate.executeUpdate();
            }

            // Paso B: Si cambió a 'entregado', registrar el dinero en Finanzas
            if ("entregado".equalsIgnoreCase(estadoLimpio)) {
                try (PreparedStatement psIngreso = con.prepareStatement(sqlIngreso)) {
                    psIngreso.setInt(1, idPedido);
                    psIngreso.setInt(2, idPedido);
                    psIngreso.executeUpdate();
                }
            }

            con.commit();
            return true;

        } catch (SQLException e) {
            System.err.println("ERROR SQL al actualizar estado de pedido: " + e.getMessage());
            e.printStackTrace();
            if (con != null) {
                try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            return false;
        } finally {
            if (con != null) {
                try { con.setAutoCommit(true); con.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
    }

    // 5. ACTUALIZAR UN PEDIDO COMPLETO (Transaccional)
    public boolean actualizarPedido(Pedido pedido) {
        String sqlPedido = "UPDATE Pedido SET cliente_id = ?, estado = ?, total = ?, notas = ?, fecha_entrega = ? WHERE id = ?";
        String sqlBorrarDetalles = "DELETE FROM Detalle_Pedido WHERE pedido_id = ?";
        String sqlInsertarDetalle = "INSERT INTO Detalle_Pedido (pedido_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        String sqlIngreso = "INSERT INTO Ingreso (concepto, monto, fecha, pedido_id) " +
                            "SELECT CONCAT('Pedido #', p.id, ' - ', COALESCE(c.nombre, 'Cliente Directo')), " +
                            "       p.total, CURRENT_DATE(), p.id " +
                            "FROM Pedido p " +
                            "LEFT JOIN Cliente c ON p.cliente_id = c.id " +
                            "WHERE p.id = ? " +
                            "AND NOT EXISTS (SELECT 1 FROM Ingreso WHERE pedido_id = ?)";

        Connection con = null;
        PreparedStatement psPedido = null;
        PreparedStatement psBorrar = null;
        PreparedStatement psDetalle = null;

        try {
            con = ConexionBD.getConexion();
            con.setAutoCommit(false); // Transacción estricta

            String estadoLimpio = (pedido.getEstado() != null) ? pedido.getEstado().replace("\"", "").trim() : "";

            // A. Actualizar datos básicos del Pedido
            psPedido = con.prepareStatement(sqlPedido);
            psPedido.setInt(1, pedido.getClienteId());
            psPedido.setString(2, estadoLimpio);
            psPedido.setDouble(3, pedido.getTotal());
            psPedido.setString(4, pedido.getNotas());
            psPedido.setString(5, pedido.getFechaEntrega());
            psPedido.setInt(6, pedido.getId());
            psPedido.executeUpdate();

            // B. Eliminar los detalles anteriores para reescribirlos
            psBorrar = con.prepareStatement(sqlBorrarDetalles);
            psBorrar.setInt(1, pedido.getId());
            psBorrar.executeUpdate();

            // C. Insertar los nuevos detalles actualizados
            if (pedido.getDetalles() != null && !pedido.getDetalles().isEmpty()) {
                psDetalle = con.prepareStatement(sqlInsertarDetalle);
                for (DetallePedido detalle : pedido.getDetalles()) {
                    psDetalle.setInt(1, pedido.getId());
                    psDetalle.setInt(2, detalle.getProductoId());
                    psDetalle.setInt(3, detalle.getCantidad());
                    psDetalle.setDouble(4, detalle.getPrecioUnitario());
                    psDetalle.addBatch();
                }
                psDetalle.executeBatch();
            }

            // D. Si el pedido queda en estado 'entregado', registrar en Finanzas si no estaba
            if ("entregado".equalsIgnoreCase(estadoLimpio)) {
                try (PreparedStatement psIngreso = con.prepareStatement(sqlIngreso)) {
                    psIngreso.setInt(1, pedido.getId());
                    psIngreso.setInt(2, pedido.getId());
                    psIngreso.executeUpdate();
                }
            }

            con.commit(); // Todo fue exitoso
            return true;
        } catch (SQLException e) {
            System.err.println("ERROR SQL al actualizar pedido: " + e.getMessage());
            if (con != null) {
                try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            return false;
        } finally {
            try { if (psPedido != null) psPedido.close(); } catch (SQLException e) {}
            try { if (psBorrar != null) psBorrar.close(); } catch (SQLException e) {}
            try { if (psDetalle != null) psDetalle.close(); } catch (SQLException e) {}
            try { if (con != null) { con.setAutoCommit(true); con.close(); } } catch (SQLException e) {}
        }
    }

    // 6. ELIMINAR PEDIDO, SUS DETALLES E INGRESOS (Transaccional)
    public boolean eliminarPedido(int idPedido) {
        String sqlIngreso = "DELETE FROM Ingreso WHERE pedido_id = ?";
        String sqlDetalles = "DELETE FROM Detalle_Pedido WHERE pedido_id = ?";
        String sqlPedido = "DELETE FROM Pedido WHERE id = ?";

        Connection con = null;
        PreparedStatement psIngreso = null;
        PreparedStatement psDetalles = null;
        PreparedStatement psPedido = null;

        try {
            con = ConexionBD.getConexion();
            con.setAutoCommit(false);

            // A. Eliminar de Ingresos si existía
            psIngreso = con.prepareStatement(sqlIngreso);
            psIngreso.setInt(1, idPedido);
            psIngreso.executeUpdate();

            // B. Eliminar detalles del pedido
            psDetalles = con.prepareStatement(sqlDetalles);
            psDetalles.setInt(1, idPedido);
            psDetalles.executeUpdate();

            // C. Borrar la cabecera del Pedido
            psPedido = con.prepareStatement(sqlPedido);
            psPedido.setInt(1, idPedido);
            int filasAfectadas = psPedido.executeUpdate();

            con.commit();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.err.println("ERROR SQL al eliminar pedido: " + e.getMessage());
            if (con != null) {
                try { con.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            return false;
        } finally {
            try { if (psIngreso != null) psIngreso.close(); } catch (SQLException e) {}
            try { if (psDetalles != null) psDetalles.close(); } catch (SQLException e) {}
            try { if (psPedido != null) psPedido.close(); } catch (SQLException e) {}
            try { if (con != null) { con.setAutoCommit(true); con.close(); } } catch (SQLException e) {}
        }
    }
}